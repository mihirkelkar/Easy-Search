THIS PROGRAM CAN BE RUN AS FOLLOWS:

	./index input_folder output_folder

Both the result will be generated and placed in the output folder. 

A file of stopwords called stopwords.txt present in the tar ball needs to be pasted in the input folder for the program to work.


Contents of TAR BALL : 1)Source code: index
2)Input files
3)postings file
4)dict file

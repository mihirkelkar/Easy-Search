Please run this program as follows:

./calcwts input-dir output-dir

if this does not run, give it user permissions: chmod +x calcwts to make it executible. 

All the weights are calculated and the code takes bout 130 seconds to run all 503 files since Python is orders of magnitude slower than other languages. At the end, the code will print out the total time taken. 

PFA: The commented code
The Report
file 25 with tf-idf calculations. 


